/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_p1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author captj_000
 */
public class Connector {
    private static final String DATABASE_URL = "jdbc:derby://localhost:1527/Magician Booking";
    private static Connection connection;
    private static final String username = "java";
    private static final String password = "java";
    
    private static PreparedStatement allHolidays;
    private static PreparedStatement allMagicians;
    private static PreparedStatement freeMagician;
    private static PreparedStatement assignMagician;
    private static PreparedStatement addWaitList;
    private static PreparedStatement allEntries;
    private static PreparedStatement addBookList;
    
    
   
    public static void setPreparedStatements() throws SQLException {
        allHolidays = connection.prepareStatement("SELECT customer, magician FROM bookinglist WHERE holiday = ?");
        //assignMagician = connection.prepareStatement("INSERT INTO magicians (magicianname) VALUES (?)");
        allMagicians = connection.prepareStatement("SELECT customer, holiday FROM bookinglist WHERE magician = ?");
        freeMagician = connection.prepareStatement("SELECT magicianname FROM magicians WHERE magicianname NOT IN (SELECT magician FROM bookinglist WHERE bookinglist.holiday = ?)");
        addWaitList = connection.prepareStatement("INSERT INTO waitlist (timestamp, holiday, customer) VALUES (?, ?, ?)");
        addBookList = connection.prepareStatement("INSERT INTO bookinglist (magician, holiday, customer) VALUES (?, ?, ?)");
        allEntries = connection.prepareStatement("SELECT customer, holiday FROM waitlist");
    }
    
    public static String newRequest(WaitListEntry wle) {
        String magician = "waitlisted";
        
        try 
        {
            getConnection();
            setPreparedStatements();
            freeMagician.setString(1, wle.getWaitHoliday());
            ResultSet resultSet = freeMagician.executeQuery();
            if(resultSet.next()){
                magician = resultSet.getString("magicianname");
                //add to booking list
                addBookList.setString(1, magician);
                addBookList.setString(2, wle.getWaitHoliday());
                addBookList.setString(3, wle.getWaitCustName());
                addBookList.executeUpdate();
            }
            else{
                addWaitList.setString(1, wle.getWaitTimestamp().toString());
                addWaitList.setString(2, wle.getWaitHoliday());
                addWaitList.setString(3, wle.getWaitCustName());
                addWaitList.executeUpdate();
                
            }
        }
        catch (SQLException sqlE)
        {
            sqlE.printStackTrace();
            close();
        }
        
        return magician;
    }
    
    public static ArrayList<WaitListEntry> getAllEntries() {
        ArrayList<WaitListEntry> list = new ArrayList<>();
        
        try
        {
            getConnection();
            setPreparedStatements();
            ResultSet resultSet = allEntries.executeQuery();
            while (resultSet.next()) {
                list.add(new WaitListEntry(resultSet.getString("customer"), resultSet.getString("holiday")));
            }
        }
        catch (SQLException sqlE)
        {
            sqlE.printStackTrace();
            close();
        }
        finally
        {
            return list;
        }
    }
    
    public static ArrayList<BookingListEntry> getWaitListByHoliday(String holiday) {
        ArrayList<BookingListEntry> holidayList = new ArrayList<>();
        
        try 
        {
            getConnection();
            setPreparedStatements();
            allHolidays.setString(1, holiday);
            ResultSet resultSet = allHolidays.executeQuery();   
            while (resultSet.next()){
                holidayList.add(new BookingListEntry(resultSet.getString("customer"), holiday, resultSet.getString("magician")));
            }
        }
        catch (SQLException sqlE)
        {
            sqlE.printStackTrace();
            close();
        }
        finally
        {
            return holidayList;
        }
    }
    
    public static ArrayList<BookingListEntry> getWaitListByMagician(String magician) {
        ArrayList<BookingListEntry> magicianList = new ArrayList<>();
        
        try 
        {
            getConnection();
            setPreparedStatements();
            allMagicians.setString(1, magician);
            ResultSet resultSet = allMagicians.executeQuery();
            while (resultSet.next()) {
                magicianList.add(new BookingListEntry(resultSet.getString("customer"), resultSet.getString("holiday"), magician));
            }
        }
        catch (SQLException sqlE)
        {
            sqlE.printStackTrace();
            close();
        }
        finally
        {
            return magicianList;
        }
    }
    
    public static Connection getConnection() {
        if (connection == null)
        {
            try
            {
                connection = DriverManager.getConnection(DATABASE_URL, username, password);
            }
            catch (SQLException sqlException2)
            {
                sqlException2.printStackTrace();
                System.exit(1);
            }
            
            return connection;
        }
        else
            return connection;
    }
    
    public static void close() {
        try
        {
            connection.close();
        }
        catch (SQLException sqlE)
        {
            sqlE.printStackTrace();
        }
    }
}
